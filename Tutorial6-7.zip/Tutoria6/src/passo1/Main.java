package passo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import passo1.controller.ControladorPedido;
import passo1.model.*;
import passo1.service.*;
import passo1.repository.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static Usuario user = new Usuario("Cliente Exemplo", "cliente@ex.com", "(11) 99999-0000");
    static List<Produto> produtos = new ArrayList<>();
    static ControladorPedido controlador = new ControladorPedido(
        new ServicoPagamento(),
        new ServicoRelatorio(),
        new ServicoNotificacao(),
        new Repositorio(),
        new DescontoBlackFriday()
    );

    public static void main(String[] args) {
        int opcao;
        do {
            System.out.println("\n=== Sistema de Pedidos ===");
            System.out.println("1 - Adicionar Produto");
            System.out.println("2 - Iniciar Pedido");
            System.out.println("3 - Adicionar Item ao Pedido");
            System.out.println("4 - Calcular total");
            System.out.println("5 - Finalizar pedido");
            System.out.println("6 - Listar produtos cadastrados");
            System.out.println("7 - Remover item do pedido");
            System.out.println("9 - Sair");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    adicionarProduto();
                    break;
                case 2:
                    iniciarPedido();
                    break;
                case 3:
                    adicionarItemAoPedido();
                    break;
                case 4:
                    calcularTotal();
                    break;
                case 5:
                    finalizarPedido();
                    break;
                case 6:
                    listarProdutos();
                    break;
                case 7:
                    removerItemDoPedido();
                    break;
                case 9:
                    System.out.println("Sair...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 9);
        sc.close();
    }

    private static void adicionarProduto() {
        System.out.print("Nome do produto: ");
        String nome = sc.nextLine();
        System.out.print("Descrição: ");
        String desc = sc.nextLine();
        System.out.print("Preço unitário: ");
        double preco = sc.nextDouble();
        System.out.print("Quantidade em estoque: ");
        int qtd = sc.nextInt();
        sc.nextLine();
        Produto produto = new Produto(nome, preco, qtd, desc);
        produtos.add(produto);
        System.out.println("Produto adicionado: " + produto);
    }

    private static void iniciarPedido() {
        System.out.println("\nSelecione o tipo de desconto:");
        System.out.println("1 - Sem desconto");
        System.out.println("2 - Desconto de R$ 20,00");
        System.out.println("3 - Desconto Black Friday (20%)");
        System.out.print("Opção: ");
        int opcaoDesconto = sc.nextInt();
        sc.nextLine();
        
        IEstrategiaDesconto descontoEscolhido;
        switch (opcaoDesconto) {
            case 1:
                descontoEscolhido = new SemDesconto();
                break;
            case 2:
                descontoEscolhido = new DescontoVinteReais();
                break;
            case 3:
                descontoEscolhido = new DescontoBlackFriday();
                break;
            default:
                System.out.println("Opção inválida, usando Sem Desconto");
                descontoEscolhido = new SemDesconto();
        }
        
        // Atualiza a estratégia de desconto no controlador
        controlador.setDesconto(descontoEscolhido);
        
        if (controlador.iniciarPedido(user)) {
            System.out.println("Pedido iniciado para o usuário: " + user.getNome());
            System.out.println("Tipo de desconto: " + descontoEscolhido.getClass().getSimpleName());
        } else {
            System.out.println("Erro ao iniciar pedido. Verifique o usuário.");
        }
    }

    private static void adicionarItemAoPedido() {
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado. Cadastre produtos primeiro (opção 1).");
            return;
        }
        System.out.print("Nome do produto: ");
        String nomeProduto = sc.nextLine();
        Produto produtoEncontrado = null;
        for (Produto p : produtos) {
            if (p.getNome().equalsIgnoreCase(nomeProduto)) {
                produtoEncontrado = p;
                break;
            }
        }
        if (produtoEncontrado == null) {
            System.out.println("Produto não encontrado!");
            return;
        }
        System.out.print("Quantidade desejada: ");
        int qtdDesejada = sc.nextInt();
        sc.nextLine();
        if (controlador.adicionarItem(produtoEncontrado, qtdDesejada)) {
            produtoEncontrado.setQuantidade(produtoEncontrado.getQuantidade() - qtdDesejada);
            System.out.println("Item adicionado ao pedido com sucesso!");
        } else {
            System.out.println("Erro ao adicionar item. Verifique estoque, quantidade ou se o pedido foi iniciado.");
        }
    }

    private static void calcularTotal() {
        Pedido pedido = controlador.getPedidoAtual();
        if (pedido == null) {
            System.out.println("Nenhum pedido iniciado.");
            return;
        }
        System.out.printf("Total original: R$ %.2f%n", pedido.calcularTotal(new SemDesconto()));
        System.out.printf("Total com desconto: R$ %.2f%n", controlador.calcularTotal());
    }

    private static void finalizarPedido() {
        Pedido pedido = controlador.getPedidoAtual();
        if (pedido == null) {
            System.out.println("Nenhum pedido iniciado.");
            return;
        }
        
        if (controlador.finalizarPedido()) {
            System.out.println("Pedido finalizado com sucesso!");
            System.out.println(pedido);
        } else {
            System.out.println("Não há itens no pedido para finalizar ou houve um erro no processamento.");
        }
    }

    private static void listarProdutos() {
        if (produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }
        System.out.println("\n=== Produtos Cadastrados ===");
        for (int i = 0; i < produtos.size(); i++) {
            System.out.println((i + 1) + " - " + produtos.get(i));
        }
    }

    private static void removerItemDoPedido() {
        Pedido pedido = controlador.getPedidoAtual();
        if (pedido == null || pedido.getTotalItens() == 0) {
            System.out.println("Não há itens no pedido ou pedido não iniciado.");
            return;
        }
        System.out.println("\n=== Itens no Pedido ===");
        for (ItemPedido item : pedido.getItens()) {
            System.out.println("- " + item);
        }
        System.out.print("Nome do produto a remover: ");
        String nomeProduto = sc.nextLine();
        Produto produtoParaRemover = null;
        for (Produto p : produtos) {
            if (p.getNome().equalsIgnoreCase(nomeProduto)) {
                produtoParaRemover = p;
                break;
            }
        }
        if (produtoParaRemover != null && pedido.removerItem(produtoParaRemover)) {
            System.out.println("Item removido do pedido.");
        } else {
            System.out.println("Item não encontrado no pedido.");
        }
    }
}