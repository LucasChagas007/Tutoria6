package passo1.service;

public class ServicoPagamento implements IPagamento {
    @Override
    public boolean processarPagamento(double total) {
        System.out.println("Processando pagamento de R$ " + total + " via gateway externo...");
        return true;
    }
}