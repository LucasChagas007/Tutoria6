package passo1.service;

public interface IPagamento {
    boolean processarPagamento(double total);
}