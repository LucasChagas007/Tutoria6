package passo1.service;

import passo1.model.Pedido;

public interface IRelatorio {
    String gerarRelatorio(Pedido pedido);
}