package passo1.model;

public interface IEstrategiaDesconto {
	public default double aplicar(double total, Pedido pedido) {
		return total;
		
	}

}
