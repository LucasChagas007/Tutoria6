package passo1.controller;

import passo1.model.Pedido;
import passo1.model.Produto;
import passo1.model.Usuario;
import passo1.service.IPagamento;
import passo1.service.IRelatorio;
import passo1.service.INotificacao;
import passo1.repository.IRepositorio;

public class ControladorPedido {
    private IPagamento servicoPagamento;
    private IRelatorio servicoRelatorio;
    private INotificacao servicoNotificacao;
    private IRepositorio repositorio;

    public ControladorPedido(IPagamento servicoPagamento, IRelatorio servicoRelatorio, 
                             INotificacao servicoNotificacao, IRepositorio repositorio) {
        this.servicoPagamento = servicoPagamento;
        this.servicoRelatorio = servicoRelatorio;
        this.servicoNotificacao = servicoNotificacao;
        this.repositorio = repositorio;
    }
    
    public boolean iniciarPedido(Usuario usuario) {
		return false;
    }
    
    public boolean adicionarItem(Produto produto, int quantidade) {
		return false;
    }
    
    public double calcularTotal(Pedido pedido) {
        return pedido.calcularTotal();
    }

    public boolean finalizarPedido(Pedido pedido) {
        if (!pedido.finalizarPedido()) {
            return false;
        }
        double total = pedido.calcularTotal();
        if (!servicoPagamento.processarPagamento(total)) {
            return false;
        }
        if (!repositorio.salvarPedido(pedido)) {
            return false;
        }
        String relatorio = servicoRelatorio.gerarRelatorio(pedido);
        return servicoNotificacao.enviarNotificacao(relatorio);
    }
}