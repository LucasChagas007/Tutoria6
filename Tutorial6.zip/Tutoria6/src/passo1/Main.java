package passo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {
    static Scanner sc = new Scanner(System.in);
    // Configura usuário fixo para demonstração
    static Usuario user = new Usuario("Cliente Exemplo", "cliente@ex.com", "(11) 99999-0000");
    static Pedido pedido = new Pedido(user);
    static List<Produto> produtos = new ArrayList<>();
    public static void main(String[] args) {
        int opcao;
        do {
            System.out.println("\n=== Sistema de Pedidos ===");
            System.out.println("1 - Adicionar Produto");
            System.out.println("2 - Adicionar Pedido");
            System.out.println("3 - Calcular total");
            System.out.println("4 - Finalizar pedido");
            System.out.println("9 - Sair");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine(); // consumir newline

            switch (opcao) {
                case 1:
                    System.out.print("Nome do produto: ");
                    String nome = sc.nextLine();
                    System.out.print("Descrição: ");
                    String desc = sc.nextLine();
                    System.out.print("Preço unitário: ");
                    double preco = sc.nextDouble();
                    System.out.print("Quantidade: ");
                    int qtd = sc.nextInt();
                    sc.nextLine();

                    Produto produto = new Produto(nome, preco, qtd, desc);
                    produtos.add(produto);
                    System.out.println("Produto adicionado: " + produto);
                    break;

                case 2:
                    if (produtos.isEmpty()) {
                        System.out.println("Nenhum produto cadastrado. Cadastre produtos primeiro (opção 1).");
                        break;
                    }
                    
                    System.out.print("Nome do produto: ");
                    String nomeProduto = sc.nextLine();
                    
                    // Buscar produto por nome
                    Produto produtoEncontrado = null;
                    for (Produto p : produtos) {
                        if (p.getNome().equalsIgnoreCase(nomeProduto)) {
                            produtoEncontrado = p;
                            break;
                        }
                    }
                    
                    if (produtoEncontrado == null) {
                        System.out.println("Produto não encontrado!");
                        break;
                    }
                    
                    System.out.print("Quantidade desejada: ");
                    int qtdDesejada = sc.nextInt();
                    sc.nextLine();
                    
                    // Verificar se há estoque suficiente
                    if (qtdDesejada > produtoEncontrado.getQuantidade()) {
                        System.out.println("Estoque insuficiente! Disponível: " + produtoEncontrado.getQuantidade());
                        break;
                    }
                    
                    // Criar item do pedido com o produto encontrado
                    ItemPedido item = new ItemPedido(produtoEncontrado, qtdDesejada);
                    Pedido.adicionarItem(item);
                    
                    // Atualizar estoque do produto
                    produtoEncontrado.setQuantidade(produtoEncontrado.getQuantidade() - qtdDesejada);
                    
                    System.out.println("Produto adicionado ao pedido: " + item);
                    break;

                case 3:
                	System.out.printf("Total do pedido: %.2f%n", pedido.calcularTotal());
                    break;
                    
                case 4:
                    if (pedido.finalizarPedido()) {
                        System.out.println("Pedido finalizado com sucesso!\n" + pedido);
                    } else {
                        System.out.println("Não há itens no pedido para finalizar.");
                    }
                    break;

                case 9:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 9);

        sc.close();
    }
}