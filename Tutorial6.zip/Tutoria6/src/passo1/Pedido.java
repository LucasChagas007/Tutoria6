package passo1;

import java.util.ArrayList;
import java.util.List;


public class Pedido {
    private Usuario solicitante;
    private static List<ItemPedido> itens = new ArrayList<>();

    public Pedido(Usuario solicitante) {
        this.solicitante = solicitante;
    }

    public Usuario getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(Usuario solicitante) {
        this.solicitante = solicitante;
    }

    public List<ItemPedido> getItens() {
        return itens;
    }
    
    public static boolean adicionarItem(ItemPedido item) {
        return itens.add(item);
    }

    public double calcularTotal() {
        double total = 0.0;
        for (ItemPedido item : itens) {
            total += item.getQuantidade() * item.getProduto().getPreco();
        }
        return total;
    }

    public boolean finalizarPedido() {
        return !itens.isEmpty();
    }

    @Override
    public String toString() {
        return String.format("Pedido[solicitante=%s, total=%.2f, itens=%s]",
                solicitante.getNome(), calcularTotal(), itens);
    }

}

