package passo1.service;

public class ServicoPagamento {
    public boolean processarPagamento(double total) {
        // Simulação de integração com API de pagamento externa
        System.out.println("Processando pagamento de R$ " + total + " via gateway externo...");
        return true;
    }
}