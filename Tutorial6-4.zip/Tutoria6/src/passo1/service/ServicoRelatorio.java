package passo1.service;

import passo1.model.Pedido;

public class ServicoRelatorio {
    public String gerarRelatorio(Pedido pedido) {
        // Simulação de geração de relatório
        return "Relatório do Pedido: Total = R$ " + pedido.calcularTotal();
    }
}