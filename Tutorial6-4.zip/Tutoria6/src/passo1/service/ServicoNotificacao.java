package passo1.service;

public class ServicoNotificacao {
    public boolean enviarNotificacao(String relatorio) {
        // Simulação de envio de notificação
        System.out.println("Enviando notificação com relatório: " + relatorio);
        return true;
    }
}