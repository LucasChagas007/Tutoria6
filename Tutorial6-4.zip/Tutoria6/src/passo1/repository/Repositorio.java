package passo1.repository;

import passo1.model.Pedido;

public class Repositorio {
    public boolean salvarPedido(Pedido pedido) {
        // Simulação de persistência no banco de dados
        System.out.println("Salvando pedido no banco de dados: " + pedido);
        return true; // Retorna true se o salvamento for bem-sucedido
    }
}