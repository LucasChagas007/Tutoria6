package passo1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import passo1.controller.ControladorPedido;
import passo1.exception.ValidacaoException;
import passo1.model.*;
import passo1.service.*;
import passo1.repository.*;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Usuario USUARIO_PADRAO = new Usuario("Cliente Exemplo", "cliente@ex.com", "(11) 99999-0000");
    private static final List<Produto> PRODUTOS = new ArrayList<>();
    private static final ControladorPedido CONTROLADOR = new ControladorPedido(
        new ServicoPagamento(),
        new ServicoRelatorio(),
        new ServicoNotificacao(),
        new Repositorio(),
        new ServicoConfiguracaoDesconto()
    );

    public static void main(String[] args) {
        exibirMenuPrincipal();
        sc.close();
    }

    private static void exibirMenuPrincipal() {
        int opcao;
        do {
            System.out.println("\n=== Sistema de Pedidos ===");
            System.out.println("1 - Gerenciar Produtos");
            System.out.println("2 - Gerenciar Pedido");
            System.out.println("9 - Sair");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    exibirMenuProdutos();
                    break;
                case 2:
                    exibirMenuPedido();
                    break;
                case 9:
                    System.out.println("Encerrando sistema...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 9);
    }

    private static void exibirMenuProdutos() {
        int opcao;
        do {
            System.out.println("\n=== Gerenciamento de Produtos ===");
            System.out.println("1 - Adicionar Produto");
            System.out.println("2 - Listar Produtos");
            System.out.println("0 - Voltar");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    adicionarProduto();
                    break;
                case 2:
                    listarProdutos();
                    break;
            }
        } while (opcao != 0);
    }

    private static void exibirMenuPedido() {
        if (CONTROLADOR.getPedidoAtual() == null) {
            iniciarPedido();
        }

        int opcao;
        do {
            System.out.println("\n=== Gerenciamento de Pedido ===");
            System.out.println("1 - Adicionar Item");
            System.out.println("2 - Remover Item");
            System.out.println("3 - Calcular Total");
            System.out.println("4 - Finalizar Pedido");
            System.out.println("0 - Voltar");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    adicionarItemAoPedido();
                    break;
                case 2:
                    removerItemDoPedido();
                    break;
                case 3:
                    calcularTotal();
                    break;
                case 4:
                    finalizarPedido();
                    return; // Sai do menu após finalizar
            }
        } while (opcao != 0);
    }

    private static void adicionarProduto() {
        System.out.print("Nome do produto: ");
        String nome = sc.nextLine();
        System.out.print("Descrição: ");
        String desc = sc.nextLine();
        System.out.print("Preço unitário: ");
        double preco = sc.nextDouble();
        System.out.print("Quantidade em estoque: ");
        int qtd = sc.nextInt();
        sc.nextLine();

        Produto produto = new Produto(nome, preco, qtd, desc);
        PRODUTOS.add(produto);
        System.out.println("Produto adicionado: " + produto);
    }

    private static void iniciarPedido() {
        if (CONTROLADOR.iniciarPedido(USUARIO_PADRAO)) {
            System.out.println("Pedido iniciado para: " + USUARIO_PADRAO.getNome());
        } else {
            System.out.println("Erro ao iniciar pedido.");
        }
    }

    private static void adicionarItemAoPedido() {
        if (PRODUTOS.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        listarProdutos();
        System.out.print("Digite o número do produto: ");
        int indice = sc.nextInt() - 1;
        sc.nextLine();

        if (indice < 0 || indice >= PRODUTOS.size()) {
            System.out.println("Índice inválido!");
            return;
        }

        Produto produto = PRODUTOS.get(indice);
        System.out.print("Quantidade desejada: ");
        int quantidade = sc.nextInt();
        sc.nextLine();

        try {
            if (CONTROLADOR.adicionarItem(produto, quantidade)) {
                System.out.println("Item adicionado com sucesso!");
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

 
    private static void calcularTotal() {
        System.out.print("Digite o cupom de desconto (ou deixe em branco): ");
        String cupom = sc.nextLine();

        double total = CONTROLADOR.calcularTotal(cupom);
        System.out.printf("Total do pedido: R$ %.2f%n", total);
    }

    private static void finalizarPedido() {
        System.out.print("Digite o cupom de desconto (ou deixe em branco): ");
        String cupom = sc.nextLine();
        
        if (CONTROLADOR.finalizarPedido(cupom)) {
            System.out.println("Pedido finalizado com sucesso!");
        } else {
            System.out.println("Erro ao finalizar pedido.");
        }
    }

    private static void listarProdutos() {
        if (PRODUTOS.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }

        System.out.println("\n=== Produtos Disponíveis ===");
        for (int i = 0; i < PRODUTOS.size(); i++) {
            System.out.printf("%d - %s%n", i + 1, PRODUTOS.get(i));
        }
    }

    private static void removerItemDoPedido() {
        Pedido pedido = CONTROLADOR.getPedidoAtual();
        if (pedido == null || pedido.getTotalItens() == 0) {
            System.out.println("Nenhum item no pedido.");
            return;
        }

        System.out.println("\n=== Itens do Pedido ===");
        List<ItemPedido> itens = pedido.getItens();
        for (int i = 0; i < itens.size(); i++) {
            System.out.printf("%d - %s%n", i + 1, itens.get(i));
        }

        System.out.print("Digite o número do item a remover: ");
        int indice = sc.nextInt() - 1;
        sc.nextLine();

        if (indice < 0 || indice >= itens.size()) {
            System.out.println("Índice inválido!");
            return;
        }

        try {
            ItemPedido item = itens.get(indice);
            Produto produto = item.getProduto();
            if (pedido.removerItem(produto)) {
                produto.setQuantidade(produto.getQuantidade() + item.getQuantidade());
                System.out.println("Item removido com sucesso!");
            }
        } catch (ValidacaoException e) {
            System.out.println("Erro ao remover item: " + e.getMessage());
        }
    }

}