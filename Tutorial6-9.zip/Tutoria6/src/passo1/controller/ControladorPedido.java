package passo1.controller;

import passo1.exception.ValidacaoException;
import passo1.model.*;
import passo1.repository.IRepositorio;
import passo1.service.*;

public class ControladorPedido {
    private final IPagamento servicoPagamento;
    private final IRelatorio servicoRelatorio;
    private final INotificacao servicoNotificacao;
    private final IRepositorio repositorio;
    private final IConfiguracaoDesconto configuracaoDesconto;
    private Pedido pedidoAtual;

    public ControladorPedido(IPagamento servicoPagamento, IRelatorio servicoRelatorio,
                           INotificacao servicoNotificacao, IRepositorio repositorio,
                           IConfiguracaoDesconto configuracaoDesconto) {
        this.servicoPagamento = servicoPagamento;
        this.servicoRelatorio = servicoRelatorio;
        this.servicoNotificacao = servicoNotificacao;
        this.repositorio = repositorio;
        this.configuracaoDesconto = configuracaoDesconto;
    }

    public boolean iniciarPedido(Usuario solicitante) {
        if (solicitante == null) return false;
        this.pedidoAtual = new Pedido(solicitante);
        return true;
    }

    public boolean adicionarItem(Produto produto, int quantidade) {
        try {
            if (pedidoAtual == null) {
                throw new ValidacaoException("Nenhum pedido iniciado");
            }
            return pedidoAtual.adicionarItem(produto, quantidade);
        } catch (ValidacaoException e) {
            System.err.println("Erro: " + e.getMessage());
            return false;
        }
    }

    public double calcularTotal(String cupomDesconto) {
        if (pedidoAtual == null) return 0.0;
        IEstrategiaDesconto estrategia = configuracaoDesconto.getEstrategia(cupomDesconto);
        return pedidoAtual.calcularTotal(estrategia);
    }

    public boolean finalizarPedido(String cupom) {
        if (pedidoAtual == null || !pedidoAtual.finalizarPedido()) {
            return false;
        }
        
        // Garante que sempre teremos uma estratégia, mesmo com cupom null
        IEstrategiaDesconto estrategia = configuracaoDesconto.getEstrategia(cupom != null ? cupom : "");
        double total = pedidoAtual.calcularTotal(estrategia);
        
        System.out.printf("Total original: R$ %.2f, Total com desconto: R$ %.2f%n", 
                pedidoAtual.calcularTotal(new SemDesconto()), total);
        
        if (!servicoPagamento.processarPagamento(total)) return false;
        if (!repositorio.salvarPedido(pedidoAtual)) return false;
        
        String relatorio = servicoRelatorio.gerarRelatorio(pedidoAtual);
        boolean notificacaoEnviada = servicoNotificacao.enviarNotificacao(relatorio);
        
        if (notificacaoEnviada) this.pedidoAtual = null;
        return notificacaoEnviada;
    }

    public Pedido getPedidoAtual() {
        return pedidoAtual;
    }
}