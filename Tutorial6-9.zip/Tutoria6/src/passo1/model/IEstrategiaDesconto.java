package passo1.model;

public interface IEstrategiaDesconto {
    double aplicar(double total, Pedido pedido);
}
