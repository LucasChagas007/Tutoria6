package passo1.model;

import passo1.exception.ValidacaoException;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private Usuario solicitante;
    private List<ItemPedido> itens;

    public Pedido(Usuario solicitante) {
        this.solicitante = solicitante;
        this.itens = new ArrayList<>();
    }

    public boolean adicionarItem(Produto produto, int quantidade) throws ValidacaoException {
        try {
            if (produto == null) throw new ValidacaoException("Produto inválido");
            if (quantidade <= 0) throw new ValidacaoException("Quantidade deve ser maior que zero");
            if (quantidade > produto.getQuantidade()) {
                throw new ValidacaoException("Estoque insuficiente");
            }

            // Verifica se o produto já está no pedido
            for (ItemPedido item : itens) {
                if (item.getProduto().equals(produto)) {
                    int novaQuantidade = item.getQuantidade() + quantidade;
                    if (novaQuantidade > produto.getQuantidade()) {
                        throw new ValidacaoException("Estoque insuficiente para quantidade adicional");
                    }
                    item.setQuantidade(novaQuantidade);
                    produto.setQuantidade(produto.getQuantidade() - quantidade);
                    return true;
                }
            }

            // Adiciona novo item
            ItemPedido novoItem = new ItemPedido(produto, quantidade);
            itens.add(novoItem);
            produto.setQuantidade(produto.getQuantidade() - quantidade);
            return true;

        } catch (ValidacaoException e) {
            throw e;
        } catch (Exception e) {
            throw new ValidacaoException("Erro ao adicionar item: " + e.getMessage());
        }
    }

    public List<ItemPedido> getItens() {
        return new ArrayList<>(itens);
    }

    public int getTotalItens() {
        return itens.size();
    }

    public double calcularTotal(IEstrategiaDesconto desconto) {
        if (desconto == null) {
            desconto = new SemDesconto(); // Estratégia padrão
        }
        
        double subtotal = itens.stream()
                             .mapToDouble(ItemPedido::calcularSubtotal)
                             .sum();
        return desconto.aplicar(subtotal, this);
    }

    public boolean finalizarPedido() {
        return !itens.isEmpty();
    }


    public boolean removerItem(Produto produto) {
        for (ItemPedido item : itens) {
            if (item.getProduto().equals(produto)) {
                produto.setQuantidade(produto.getQuantidade() + item.getQuantidade());
                itens.remove(item);
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        IEstrategiaDesconto descontoPadrao = new SemDesconto();
        double total = calcularTotal(descontoPadrao);
        
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Pedido[solicitante=%s, total=%.2f, itens=%d]\n",
                solicitante != null ? solicitante.getNome() : "N/A",
                total,
                itens.size()));
        
        for (ItemPedido item : itens) {
            sb.append("  - ").append(item).append("\n");
        }
        return sb.toString();
    }
}