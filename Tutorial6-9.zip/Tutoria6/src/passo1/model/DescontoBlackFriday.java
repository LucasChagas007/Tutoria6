package passo1.model;

public class DescontoBlackFriday implements IEstrategiaDesconto {
    public double aplicar(double total, Pedido pedido) {
        return total * 0.8; // 20% de desconto
    }
}