package passo1.model;

public class DescontoVinteReais implements IEstrategiaDesconto {
    public double aplicar(double total, Pedido pedido) {
        return Math.max(0, total - 20); // Desconto de R$ 20,00 (mínimo 0)
    }
}
