package passo1.exception;

public class ProdutoInvalidoException extends ValidacaoException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProdutoInvalidoException(String message) {
        super(message);
    }
}
