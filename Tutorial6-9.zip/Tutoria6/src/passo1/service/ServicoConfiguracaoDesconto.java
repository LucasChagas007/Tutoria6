package passo1.service;

import passo1.model.*;
import java.util.HashMap;
import java.util.Map;

public class ServicoConfiguracaoDesconto implements IConfiguracaoDesconto {
    private final Map<String, IEstrategiaDesconto> estrategias;
    
    public ServicoConfiguracaoDesconto() {
        this.estrategias = new HashMap<>();
        // Estratégia padrão para cupom vazio ou null
        estrategias.put("", new SemDesconto());
        // Outras estratégias
        estrategias.put("BLACKFRIDAY", new DescontoBlackFriday());
        estrategias.put("DESCONTO20", new DescontoVinteReais());
    }
    
    @Override
    public IEstrategiaDesconto getEstrategia(String cupomDesconto) {
        String chave = cupomDesconto != null ? cupomDesconto.toUpperCase() : "";
        return estrategias.getOrDefault(chave, new SemDesconto());
    }
}