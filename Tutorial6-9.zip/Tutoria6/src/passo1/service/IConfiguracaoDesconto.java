package passo1.service;

import passo1.model.IEstrategiaDesconto;

public interface IConfiguracaoDesconto {
    IEstrategiaDesconto getEstrategia(String cupomDesconto);
}