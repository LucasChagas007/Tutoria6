package passo1.model;

public class DescontoVinteReais implements IEstrategiaDesconto {
    public double aplicar(double total, Pedido pedido) {
        return total - 20;
    }

}
