// DescontoBlackFriday.java
package passo1.model;

public class DescontoBlackFriday implements IEstrategiaDesconto {
    public double aplicar(double total, Pedido pedido) {
        if (total <= 0) {
            return total;
        }
        double desconto = total * 0.2; // Corrigido o cálculo do desconto (20%)
        return total - desconto;
    }
}