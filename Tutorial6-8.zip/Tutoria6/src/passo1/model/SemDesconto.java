package passo1.model;

public class SemDesconto implements IEstrategiaDesconto {
    public double aplicar(double total, Pedido pedido) {
        return total;
    }

}
