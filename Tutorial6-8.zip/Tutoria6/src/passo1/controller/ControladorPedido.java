package passo1.controller;

import passo1.model.Pedido;
import passo1.model.Produto;
import passo1.model.SemDesconto;
import passo1.model.Usuario;
import passo1.service.IPagamento;
import passo1.service.IRelatorio;
import passo1.service.INotificacao;
import passo1.model.IEstrategiaDesconto;
import passo1.repository.IRepositorio;
import passo1.service.ServicoValidacao;
import passo1.exception.ValidacaoException;

public class ControladorPedido {
    private IPagamento servicoPagamento;
    private IRelatorio servicoRelatorio;
    private INotificacao servicoNotificacao;
    private IRepositorio repositorio;
    private IEstrategiaDesconto desconto;
    private Pedido pedidoAtual;
    private final ServicoValidacao servicoValidacao;

    public ControladorPedido(IPagamento servicoPagamento, IRelatorio servicoRelatorio, 
                           INotificacao servicoNotificacao, IRepositorio repositorio, IEstrategiaDesconto desconto) {
        this.servicoPagamento = servicoPagamento;
        this.servicoRelatorio = servicoRelatorio;
        this.servicoNotificacao = servicoNotificacao;
        this.repositorio = repositorio;
        this.desconto = desconto;
        this.servicoValidacao = new ServicoValidacao();
    }
    
    public boolean iniciarPedido(Usuario usuario) {
        if (usuario == null) {
            return false;
        }
        this.pedidoAtual = new Pedido(usuario);
        return true;
    }
    
    public boolean adicionarItem(Produto produto, int quantidade) {
        try {
            servicoValidacao.validarEstoque(produto, quantidade);
            
            if (pedidoAtual == null) {
                return false;
            }
            
            return pedidoAtual.adicionarItem(produto, quantidade);
            
        } catch (ValidacaoException e) {
            System.err.println("Erro de validação: " + e.getMessage());
            return false;
        }
    }
    
    public void setDesconto(IEstrategiaDesconto desconto) {
        this.desconto = desconto;
    }
    
    public double calcularTotal() {
        if (pedidoAtual == null) {
            return 0.0;
        }
        return pedidoAtual.calcularTotal(desconto);
    }

    public boolean finalizarPedido() {
        if (pedidoAtual == null || !pedidoAtual.finalizarPedido()) {
            return false;
        }
        double total = pedidoAtual.calcularTotal(desconto);
        System.out.printf("Total original: R$ %.2f, Total com desconto: R$ %.2f%n", 
                pedidoAtual.calcularTotal(new SemDesconto()), total);
        
        if (!servicoPagamento.processarPagamento(total)) {
            return false;
        }
        if (!repositorio.salvarPedido(pedidoAtual)) {
            return false;
        }
        String relatorio = servicoRelatorio.gerarRelatorio(pedidoAtual);
        boolean notificacaoEnviada = servicoNotificacao.enviarNotificacao(relatorio);
        if (notificacaoEnviada) {
            this.pedidoAtual = null;
        }
        return notificacaoEnviada;
    }

    public Pedido getPedidoAtual() {
        return pedidoAtual;
    }
}