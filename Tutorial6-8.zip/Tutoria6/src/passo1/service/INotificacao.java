package passo1.service;

public interface INotificacao {
    boolean enviarNotificacao(String relatorio);
}