package passo1.model;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private Usuario solicitante;
    private static List<ItemPedido> itens;

    public Pedido() {
        Pedido.itens = new ArrayList<>();
    }

    public Pedido(Usuario solicitante) {
        this.solicitante = solicitante;
        Pedido.itens = new ArrayList<>();
    }

    public Usuario getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(Usuario solicitante) {
        this.solicitante = solicitante;
    }

    public List<ItemPedido> getItens() {
        return new ArrayList<>(itens);
    }

    public boolean adicionarItem(Produto produto, int quantidade) {
        if (produto == null || quantidade <= 0 || quantidade > produto.getQuantidade()) {
            return false;
        }
        for (ItemPedido item : itens) {
            if (item.getProduto().equals(produto)) {
                int novaQuantidade = item.getQuantidade() + quantidade;
                if (novaQuantidade > produto.getQuantidade()) {
                    return false;
                }
                item.setQuantidade(novaQuantidade);
                return true;
            }
        }
        ItemPedido novoItem = new ItemPedido(produto, quantidade);
        return itens.add(novoItem);
    }

    public boolean removerItem(Produto produto) {
        return itens.removeIf(item -> item.getProduto().equals(produto));
    }

    public static double calcularTotal() {
        return itens.stream().mapToDouble(ItemPedido::calcularSubtotal).sum();
    }

    public boolean finalizarPedido() {
        return !itens.isEmpty();
    }

    public int getTotalItens() {
        return itens.size();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Pedido[solicitante=%s, total=%.2f, itens=%d]\n",
                solicitante != null ? solicitante.getNome() : "N/A",
                calcularTotal(),
                itens.size()));
        for (ItemPedido item : itens) {
            sb.append("  - ").append(item).append("\n");
        }
        return sb.toString();
    }
}