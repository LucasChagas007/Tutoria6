package passo1.service;

import passo1.model.Pedido;

public class ServicoRelatorio {
    public String gerarRelatorio(Pedido pedido) {
        return "Relatório do Pedido: Total = R$ " + Pedido.calcularTotal();
    }
}