package passo1.service;

public class ServicoNotificacao {
    public boolean enviarNotificacao(String relatorio) {
        System.out.println("Enviando notificação com relatório: " + relatorio);
        return true;
    }
}