package passo1.controller;

import passo1.model.Pedido;
import passo1.model.Produto;
import passo1.model.Usuario;
import passo1.service.ServicoPagamento;
import passo1.service.ServicoRelatorio;
import passo1.service.ServicoNotificacao;
import passo1.repository.Repositorio;

public class ControladorPedido {
    private ServicoPagamento servicoPagamento;
    private ServicoRelatorio servicoRelatorio;
    private ServicoNotificacao servicoNotificacao;
    private Repositorio repositorio;

    public ControladorPedido() {
        this.servicoPagamento = new ServicoPagamento();
        this.servicoRelatorio = new ServicoRelatorio();
        this.servicoNotificacao = new ServicoNotificacao();
        this.repositorio = new Repositorio();
    }
    
    public boolean iniciarPedido(Usuario usuario) {
		return false;
    }
    
    public boolean adicionarItem(Produto produto, int quantidade) {
		return false;
    }
    
    public double calcularTotal() {
        return Pedido.calcularTotal();
    }

    public boolean finalizarPedido(Pedido pedido) {
        if (!pedido.finalizarPedido()) {
            return false;
        }
        double total = Pedido.calcularTotal();
        if (!servicoPagamento.processarPagamento(total)) {
            return false;
        }
        if (!repositorio.salvarPedido(pedido)) {
            return false;
        }
        String relatorio = servicoRelatorio.gerarRelatorio(pedido);
        return servicoNotificacao.enviarNotificacao(relatorio);
    }
}