package passo1.repository;

import passo1.model.Pedido;

public class Repositorio {
    public boolean salvarPedido(Pedido pedido) {
        System.out.println("Salvando pedido no banco de dados: " + pedido);
        return true;
    }
}