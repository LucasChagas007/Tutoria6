package passo1.service;

public class ServicoNotificacao implements INotificacao {
    public boolean enviarNotificacao(String mensagem) {
        System.out.println("Notificação enviada: " + mensagem);
        return true;
    }
}