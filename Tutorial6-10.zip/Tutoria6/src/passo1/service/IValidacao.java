package passo1.service;

import passo1.model.Produto;
import passo1.exception.ProdutoInvalidoException;
import passo1.exception.EstoqueInsuficienteException;
import java.math.BigDecimal;

public interface IValidacao {
    static void validarProduto(Produto produto) {
        if (produto == null) {
            throw new ProdutoInvalidoException("Produto não pode ser nulo");
        }
        if (produto.getNome() == null || produto.getNome().trim().isEmpty()) {
            throw new ProdutoInvalidoException("Nome do produto não pode ser vazio");
        }
        if (produto.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ProdutoInvalidoException("Preço do produto deve ser positivo");
        }
        if (produto.getQuantidade() < 0) {
            throw new ProdutoInvalidoException("Quantidade em estoque não pode ser negativa");
        }
    }
    
    static void validarEstoque(Produto produto, int quantidade) {
        validarProduto(produto); // Primeiro valida o produto
        
        if (quantidade <= 0) {
            throw new EstoqueInsuficienteException("Quantidade deve ser maior que zero");
        }
        if (quantidade > produto.getQuantidade()) {
            throw new EstoqueInsuficienteException(
                String.format("Estoque insuficiente. Disponível: %d, Solicitado: %d", 
                produto.getQuantidade(), quantidade)
            );
        }
    }
}