package passo1.service;

import passo1.model.Moeda;
import java.math.BigDecimal;

public class ServicoConversorMoeda implements IConversorMoeda {
    @Override
    public Moeda converter(Moeda valor, String codigoDestino) {
        if (valor.getCodigo().equals(codigoDestino)) {
            return valor;
        }
        
        BigDecimal taxa = obterTaxaConversao(valor.getCodigo(), codigoDestino);
        BigDecimal valorConvertido = valor.getValor().multiply(taxa);
        return new Moeda(valorConvertido, codigoDestino);
    }

    private BigDecimal obterTaxaConversao(String origem, String destino) {
        // Simulação - em produção viria de uma API
        if (origem.equals("BRL") && destino.equals("USD")) return new BigDecimal("0.19");
        if (origem.equals("USD") && destino.equals("BRL")) return new BigDecimal("5.20");
        return BigDecimal.ONE;
    }
}