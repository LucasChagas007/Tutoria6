package passo1.service;

import passo1.model.Pedido;

public class ServicoRelatorio implements IRelatorio {
    public String gerarRelatorio(Pedido pedido) {
        return "Relatório do pedido: " + pedido.toString();
    }
}