package passo1.service;

import passo1.model.Produto;
import passo1.exception.ValidacaoException;

public class ServicoValidacao implements IValidacao {
    
    public void validarProduto(Produto produto) throws ValidacaoException {
        try {
            IValidacao.validarProduto(produto);
        } catch (ValidacaoException e) {
            throw e; // Re-lança exceções específicas
        } catch (Exception e) {
            throw new ValidacaoException("Erro ao validar produto");
        }
    }
    
    public void validarEstoque(Produto produto, int quantidade) throws ValidacaoException {
        try {
            IValidacao.validarEstoque(produto, quantidade);
        } catch (ValidacaoException e) {
            throw e; // Re-lança exceções específicas
        } catch (Exception e) {
            throw new ValidacaoException("Erro ao validar estoque");
        }
    }
}