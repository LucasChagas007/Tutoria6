package passo1.service;

import passo1.model.Moeda;

public interface IConversorMoeda {
    Moeda converter(Moeda valor, String codigoDestino);
}