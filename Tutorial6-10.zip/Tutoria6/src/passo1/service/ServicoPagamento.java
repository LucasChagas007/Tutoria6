package passo1.service;

import java.math.BigDecimal;

public class ServicoPagamento implements IPagamento {
    public boolean processarPagamento(BigDecimal valor) {
        System.out.printf("Processando pagamento de %.2f...%n", valor);
        return true; // Simulação sempre bem-sucedida
    }
}