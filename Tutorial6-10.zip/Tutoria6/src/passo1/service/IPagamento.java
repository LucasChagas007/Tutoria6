package passo1.service;

import java.math.BigDecimal;

public interface IPagamento {
	boolean processarPagamento(BigDecimal valor);
}