package passo1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import passo1.controller.ControladorPedido;
import passo1.model.*;
import passo1.service.*;
import passo1.repository.*;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Usuario USUARIO = new Usuario("Cliente", "cliente@email.com", "(11) 99999-9999");
    private static final List<Produto> PRODUTOS = new ArrayList<>();
    private static final ControladorPedido CONTROLADOR = new ControladorPedido(
        new ServicoPagamento(),
        new ServicoRelatorio(),
        new ServicoNotificacao(),
        new Repositorio(),
        new ServicoConfiguracaoDesconto(),
        new ServicoConversorMoeda()
    );

    public static void main(String[] args) {
        carregarDadosIniciais();
        exibirMenuPrincipal();
        sc.close();
    }

    private static void carregarDadosIniciais() {
        PRODUTOS.add(new Produto("Notebook", new BigDecimal("4500.00"), 10, "Notebook i7 16GB"));
        PRODUTOS.add(new Produto("Mouse", new BigDecimal("120.50"), 30, "Mouse sem fio"));
    }

    private static void exibirMenuPrincipal() {
        int opcao;
        do {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Gerenciar Produtos");
            System.out.println("2. Gerenciar Pedido");
            System.out.println("9. Sair");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1: exibirMenuProdutos(); break;
                case 2: exibirMenuPedido(); break;
            }
        } while (opcao != 9);
    }

    private static void exibirMenuProdutos() {
        int opcao;
        do {
            System.out.println("\n=== PRODUTOS ===");
            System.out.println("1. Listar");
            System.out.println("2. Adicionar");
            System.out.println("0. Voltar");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1: listarProdutos(); break;
                case 2: adicionarProduto(); break;
            }
        } while (opcao != 0);
    }

    private static void exibirMenuPedido() {
        if (CONTROLADOR.getPedidoAtual() == null) {
            CONTROLADOR.iniciarPedido(USUARIO);
        }

        int opcao;
        do {
            System.out.println("\n=== PEDIDO ===");
            System.out.println("1. Adicionar Item");
            System.out.println("2. Remover Item");
            System.out.println("3. Calcular Total");
            System.out.println("4. Finalizar");
            System.out.println("0. Voltar");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1: adicionarItem(); break;
                case 2: removerItem(); break;
                case 3: calcularTotal(); break;
                case 4: finalizarPedido(); return;
            }
        } while (opcao != 0);
    }

    private static void listarProdutos() {
        System.out.println("\n=== LISTA DE PRODUTOS ===");
        for (int i = 0; i < PRODUTOS.size(); i++) {
            System.out.printf("%d. %s%n", i+1, PRODUTOS.get(i));
        }
    }

    private static void adicionarProduto() {
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Preço: ");
        BigDecimal preco = sc.nextBigDecimal();
        System.out.print("Quantidade: ");
        int quantidade = sc.nextInt();
        sc.nextLine();
        System.out.print("Descrição: ");
        String descricao = sc.nextLine();

        PRODUTOS.add(new Produto(nome, preco, quantidade, descricao));
        System.out.println("Produto adicionado!");
    }

    private static void adicionarItem() {
        listarProdutos();
        System.out.print("Número do produto: ");
        int indice = sc.nextInt() - 1;
        System.out.print("Quantidade: ");
        int quantidade = sc.nextInt();
        sc.nextLine();

        if (indice >= 0 && indice < PRODUTOS.size()) {
            if (CONTROLADOR.adicionarItem(PRODUTOS.get(indice), quantidade)) {
                System.out.println("Item adicionado ao pedido!");
            } else {
                System.out.println("Erro ao adicionar item.");
            }
        } else {
            System.out.println("Produto inválido!");
        }
    }

    private static void removerItem() {
        Pedido pedido = CONTROLADOR.getPedidoAtual();
        if (pedido == null || pedido.getTotalItens() == 0) {
            System.out.println("Nenhum item no pedido!");
            return;
        }

        System.out.println("\nITENS DO PEDIDO:");
        List<ItemPedido> itens = pedido.getItens();
        for (int i = 0; i < itens.size(); i++) {
            System.out.printf("%d. %s%n", i+1, itens.get(i));
        }

        System.out.print("Número do item a remover: ");
        int indice = sc.nextInt() - 1;
        sc.nextLine();

        if (indice >= 0 && indice < itens.size()) {
            if (pedido.removerItem(itens.get(indice).getProduto())) {
                System.out.println("Item removido!");
            } else {
                System.out.println("Erro ao remover item.");
            }
        } else {
            System.out.println("Item inválido!");
        }
    }

    private static void calcularTotal() {
        System.out.print("Cupom (opcional): ");
        String cupom = sc.nextLine();
        Moeda total = CONTROLADOR.calcularTotal(cupom);
        System.out.printf("TOTAL DO PEDIDO: %s%n", total);
    }

    private static void finalizarPedido() {
        System.out.print("Cupom (opcional): ");
        String cupom = sc.nextLine();
        if (CONTROLADOR.finalizarPedido(cupom)) {
            System.out.println("Pedido finalizado com sucesso!");
        } else {
            System.out.println("Erro ao finalizar pedido.");
        }
    }
}