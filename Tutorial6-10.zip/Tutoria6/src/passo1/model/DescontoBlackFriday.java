package passo1.model;

import java.math.BigDecimal;

public class DescontoBlackFriday implements IEstrategiaDesconto {
    @Override
    public Moeda aplicar(Moeda total, Pedido pedido) {
        BigDecimal desconto = total.getValor().multiply(new BigDecimal("0.2"));
        return new Moeda(total.getValor().subtract(desconto), total.getCodigo());
    }
}