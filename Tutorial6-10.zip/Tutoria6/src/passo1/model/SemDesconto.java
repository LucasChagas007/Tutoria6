package passo1.model;

public class SemDesconto implements IEstrategiaDesconto {
    public Moeda aplicar(Moeda total, Pedido pedido) {
        return total;
    }
}