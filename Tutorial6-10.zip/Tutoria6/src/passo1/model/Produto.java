package passo1.model;

import java.math.BigDecimal;

public class Produto {
    private final String nome;
    private final BigDecimal preco;
    private int quantidade;
    private final String descricao;

    public Produto(String nome, BigDecimal preco, int quantidade, String descricao) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.descricao = descricao;
    }

    // Getters
    public String getNome() { return nome; }
    public BigDecimal getPreco() { return preco; }
    public int getQuantidade() { return quantidade; }
    public String getDescricao() { return descricao; }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return String.format("Produto[nome=%s, preco=%.2f, quantidade=%d]", nome, preco, quantidade);
    }
}