package passo1.model;

import passo1.exception.ValidacaoException;
import passo1.service.IConversorMoeda;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private final String codigoMoeda;
    private final Usuario solicitante;
    private final List<ItemPedido> itens;
    private final IConversorMoeda conversorMoeda;

    public Pedido(String codigoMoeda, Usuario solicitante, IConversorMoeda conversorMoeda) {
        this.codigoMoeda = codigoMoeda;
        this.solicitante = solicitante;
        this.conversorMoeda = conversorMoeda;
        this.itens = new ArrayList<>();
    }

    public boolean adicionarItem(Produto produto, int quantidade) throws ValidacaoException {
        if (produto == null) throw new ValidacaoException("Produto não pode ser nulo");
        if (quantidade <= 0) throw new ValidacaoException("Quantidade deve ser positiva");
        if (quantidade > produto.getQuantidade()) throw new ValidacaoException("Estoque insuficiente");

        for (ItemPedido item : itens) {
            if (item.getProduto().equals(produto)) {
                int novaQuantidade = item.getQuantidade() + quantidade;
                if (novaQuantidade > produto.getQuantidade()) {
                    throw new ValidacaoException("Estoque insuficiente para quantidade adicional");
                }
                item.setQuantidade(novaQuantidade);
                produto.setQuantidade(produto.getQuantidade() - quantidade);
                return true;
            }
        }

        itens.add(new ItemPedido(produto, quantidade));
        produto.setQuantidade(produto.getQuantidade() - quantidade);
        return true;
    }

    public boolean removerItem(Produto produto) {
        for (ItemPedido item : itens) {
            if (item.getProduto().equals(produto)) {
                produto.setQuantidade(produto.getQuantidade() + item.getQuantidade());
                itens.remove(item);
                return true;
            }
        }
        return false;
    }

    public Moeda calcularTotal(IEstrategiaDesconto desconto) {
        BigDecimal subtotal = itens.stream()
            .map(ItemPedido::calcularSubtotal)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        Moeda total = new Moeda(subtotal, codigoMoeda);
        return desconto != null ? desconto.aplicar(total, this) : total;
    }

    public Moeda converterMoeda(Moeda valor, String codigoDestino) {
        return conversorMoeda.converter(valor, codigoDestino);
    }

    // Getters
    public List<ItemPedido> getItens() { return new ArrayList<>(itens); }
    public int getTotalItens() { return itens.size(); }
    public boolean finalizarPedido() { return !itens.isEmpty(); }

	public Usuario getSolicitante() {
		return solicitante;
	}
	
	@Override
	public String toString() {
	    IEstrategiaDesconto descontoPadrao = new SemDesconto();
	    Moeda total = calcularTotal(descontoPadrao);
	    
	    StringBuilder sb = new StringBuilder();
	    sb.append(String.format("Pedido[total=%s %.2f, itens=%d]\n",
	            total.getCodigo(),  // Símbolo da moeda (ex: "BRL")
	            total.getValor(),   // Valor BigDecimal
	            itens.size()));
	    
	    for (ItemPedido item : itens) {
	        sb.append("  - ").append(item).append("\n");
	    }
	    return sb.toString();
	}
}