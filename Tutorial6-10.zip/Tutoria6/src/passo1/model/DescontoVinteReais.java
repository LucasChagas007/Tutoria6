package passo1.model;

import java.math.BigDecimal;

public class DescontoVinteReais implements IEstrategiaDesconto {
    @Override
    public Moeda aplicar(Moeda total, Pedido pedido) {
        BigDecimal valorComDesconto = total.getValor().subtract(new BigDecimal("20"));
        return new Moeda(valorComDesconto.max(BigDecimal.ZERO), total.getCodigo());
    }
}