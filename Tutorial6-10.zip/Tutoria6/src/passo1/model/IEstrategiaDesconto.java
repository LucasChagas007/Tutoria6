package passo1.model;

public interface IEstrategiaDesconto {
    Moeda aplicar(Moeda total, Pedido pedido);
}