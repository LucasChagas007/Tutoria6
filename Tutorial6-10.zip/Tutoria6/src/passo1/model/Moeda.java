package passo1.model;

import java.math.BigDecimal;

public class Moeda {
    private final BigDecimal valor;
    private final String codigo;

    public Moeda(BigDecimal valor, String codigo) {
        this.valor = valor;
        this.codigo = codigo;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public String getCodigo() {
        return codigo;
    }

    @Override
    public String toString() {
        return String.format("%s %.2f", codigo, valor);
    }
}