package passo1.repository;

import passo1.model.Pedido;

public interface IRepositorio {
    boolean salvarPedido(Pedido pedido);
}