package passo1.repository;

import passo1.model.Pedido;

public class Repositorio implements IRepositorio {
    public boolean salvarPedido(Pedido pedido) {
        System.out.println("Pedido salvo no repositório: " + pedido);
        return true;
    }
}