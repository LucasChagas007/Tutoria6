package passo1.controller;

import java.math.BigDecimal;

import passo1.model.*;
import passo1.repository.IRepositorio;
import passo1.service.*;

public class ControladorPedido {
    private final IPagamento servicoPagamento;
    private final IRelatorio servicoRelatorio;
    private final INotificacao servicoNotificacao;
    private final IRepositorio repositorio;
    private final IConfiguracaoDesconto configuracaoDesconto;
    private final IConversorMoeda conversorMoeda;
    private Pedido pedidoAtual;

    public ControladorPedido(IPagamento servicoPagamento, IRelatorio servicoRelatorio,
                           INotificacao servicoNotificacao, IRepositorio repositorio,
                           IConfiguracaoDesconto configuracaoDesconto,
                           IConversorMoeda conversorMoeda) {
        this.servicoPagamento = servicoPagamento;
        this.servicoRelatorio = servicoRelatorio;
        this.servicoNotificacao = servicoNotificacao;
        this.repositorio = repositorio;
        this.configuracaoDesconto = configuracaoDesconto;
        this.conversorMoeda = conversorMoeda;
    }

    public boolean iniciarPedido(Usuario usuario) {
        if (usuario == null) return false;
        this.pedidoAtual = new Pedido("BRL", usuario, conversorMoeda);
        return true;
    }

    public boolean adicionarItem(Produto produto, int quantidade) {
        try {
            return pedidoAtual != null && pedidoAtual.adicionarItem(produto, quantidade);
        } catch (Exception e) {
            System.err.println("Erro: " + e.getMessage());
            return false;
        }
    }

    public Moeda calcularTotal(String cupom) {
        if (pedidoAtual == null) return new Moeda(BigDecimal.ZERO, "BRL");
        IEstrategiaDesconto estrategia = configuracaoDesconto.getEstrategia(cupom);
        return pedidoAtual.calcularTotal(estrategia);
    }

    public boolean finalizarPedido(String cupom) {
        if (pedidoAtual == null || !pedidoAtual.finalizarPedido()) return false;
        
        Moeda total = calcularTotal(cupom);
        if (!servicoPagamento.processarPagamento(total.getValor())) return false;
        if (!repositorio.salvarPedido(pedidoAtual)) return false;
        
        String relatorio = servicoRelatorio.gerarRelatorio(pedidoAtual);
        boolean notificado = servicoNotificacao.enviarNotificacao(relatorio);
        
        if (notificado) pedidoAtual = null;
        return notificado;
    }

    public Pedido getPedidoAtual() {
        return pedidoAtual;
    }
}